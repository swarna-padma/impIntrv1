# Advanced Kubernetes course
This repository contains the course files for my Advanced Kubernetes course on Udemy. See https://www.udemy.com/learn-devops-advanced-kubernetes-usage/?couponCode=GITHUB
