# Auth0 Python Web App Sample

Original: https://github.com/auth0-samples/auth0-python-web-app/tree/master/01-Login

Adapted to be used with Kubernetes

