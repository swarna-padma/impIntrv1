const {
  WebClient
} = require('@slack/web-api');
const fs = require('fs');

const AppName = "slack-helper";
const WaitTime = 1000;
const SlackToken = process.env.SLACK_TOKEN;
const DataPath = "./data/";
const OutputFile = DataPath+"slack-userids.json";
const BatchSize = 30;
const GetUseridTime = 1000;
const InviteManyTime = 1500;

const web = new WebClient(SlackToken);

let usersList = [];
let channelId = null;
let inviteesList = null;
let fileName = "";


function displayError(result) {
  if (result.code && result.data) {
    console.error('Slack error code: ',result.code);
    console.error('Slack error message: ', result.data.error);
  } else {
    console.error('Slack error return: ', result);
  }
}

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

function readTextFile(file){
  let invitees = null;
  try {
    invitees = fs.readFileSync(file, 'utf-8');
    invitees = invitees.split('\n');
    invitees = invitees.map(function(entry){ return entry.replace(/\s+/g,'') });
    invitees = invitees.filter(function(entry){ return entry != null && entry != ''; });
    //console.log(invitees);
  } catch(error){
    console.error('FS read error: ', error);
  }
  return invitees;
}

function readFromFile(file){
  let data = null;
  try {
    data = fs.readFileSync(file, 'utf-8');
    data = JSON.parse(data);
  } catch(error){
    console.error('FS read error: ', error);
  }
  return data;
}

function saveToFile(data, file) {
  let response = null;
  try {
    response = fs.writeFileSync(file, JSON.stringify(data), 'utf-8');
  } catch(error){
    console.error('FS write error: ', error);
  }
  return response;
}

function saveStringToFile(data, file) {
  let response = null;
  try {
    response = fs.writeFileSync(file, data, 'utf-8');
  } catch(error){
    console.error('FS write error: ', error);
  }
  return response;
}

// https://api.slack.com/methods/conversations.create
// Scopes: channels:manage, groups:write, im:write, mpim:write
async function createSlackChannel(name, private){
  let channelId = null;
  await web.conversations.create({
    name: name,
    is_private: private
  }).then(function(data){
    channelId = data.channel.id;
  }).catch(function(res) {
    displayError(res);
  });
  return channelId;
}

// https://api.slack.com/methods/conversations.invite
// Scopes: channels:manage, groups:write, im:write, mpim:write
async function inviteUsersToSlackChannel(channelId, userids) {
  let ok = false;
  await web.conversations.invite({
    channel: channelId,
    users: userids
  }).then(function(data){
    ok = data.ok;
  }).catch(function(res){
    ok = false;
    console.error(res.data.error);
  });
  return ok;
}

async function inviteManyToSlackChannel(channelId, userids) {
  let counter = 1;
  let batchedUsers = "";
  let success = 0;
  console.log(AppName+' - Inviting many to a Slack Channel! Grab a cup of coffee!');
  console.log(AppName+' - Estimated time to completion: %i min', Math.round((userids.length*(InviteManyTime + WaitTime)/(60000))));
  for (let i = 0, length = userids.length; i < length; i++) {
    // smoother to avoid Slack dropping connctions
    await sleep(WaitTime);
    if (userids[i].userid) {
      if (batchedUsers == "") {
        batchedUsers = userids[i].userid;
        counter++;
      } else {
        batchedUsers = batchedUsers+','+userids[i].userid;
        counter++;
      }
    }
    if (counter > BatchSize) {
      const ok = await inviteUsersToSlackChannel(channelId, batchedUsers);
      if (ok) {
          success = success + BatchSize;
          process.stdout.write('.');
      } else {
        process.stdout.write('!');
      }
      batchedUsers = "";
      counter = 1;
    }
  }
  console.log('');
  return success;
}

// https://api.slack.com/methods/users.lookupByEmail
// Scopes: users:read.email
async function getSlackUserIds(emails) {
  let users = [];
  console.log(AppName+' - Looking up userids by e-mail! Sit down and relax!');
  console.log(AppName+' - Estimated time to completion: %i min', Math.round(emails.length*(GetUseridTime+WaitTime)/60000));
  for (let i = 0, length = emails.length; i < length; i++) {
    // smoother to avoid Slack dropping connctions
    await sleep(WaitTime);
    await web.users.lookupByEmail({
      email: emails[i]
    }).then(function(data){
      process.stdout.write('.');
      //console.log(data.user);
      users.push({
        email: emails[i],
        userid: data.user.id,
        team_id: data.user.team_id,
        name: data.user.name,
        status: 'ok'
      });
    }).catch(function(res){
      process.stdout.write('!');
      users.push({
        email: emails[i],
        userid: '',
        team_id: '',
        name: '',
        status: res.data.error
      });
    });
  }
  console.log('');
  return users;
}

// https://api.slack.com/methods/users.profile.get
// Scopes: users.profile:read
async function getSlackUserEmails(members) {
  let emails = "";
  let email = "";
  console.log(AppName+' - Looking up e-mail by userid! Sit down and relax!');
  console.log(AppName+' - Estimated time to completion: %i min', Math.round(members.length*(GetUseridTime+WaitTime)/60000));
  for (let i = 0, length = members.length; i < length; i++) {
    // smoother to avoid Slack dropping connctions
    await sleep(WaitTime);
    await web.users.profile.get({
      user: members[i].userid
    }).then(function(data){
      process.stdout.write('.');
      email = `${data.profile.real_name},${data.profile.display_name},${data.profile.email}\n`
      emails += email;
      //console.log(emails);
    }).catch(function(res){
      console.error(res);
      process.stdout.write('!');
      emails += `Error: ${members[i].userid}\n`;
    });
  }
  console.log('');
  return emails;
}



// https://api.slack.com/methods/conversations.members
// Scopes: channels:read, groups:read
async function getAllChannelMembers(options) {
  async function pageLoaded(accumulatedMembers, res) {
    // Merge the previous result with the results in the current page
    const mergedMembers = accumulatedMembers.concat(res.members);

    // When a `next_cursor` exists, recursively call this function to get the next page.
    if (res.response_metadata && res.response_metadata.next_cursor && res.response_metadata.next_cursor !== '') {
      // Make a copy of options
      const pageOptions = { ...options };
      // Add the `cursor` argument
      pageOptions.cursor = res.response_metadata.next_cursor;
      process.stdout.write('.');
      return pageLoaded(mergedMembers, await web.conversations.members(pageOptions));
    }

    // Otherwise, we're done and can return the result
    console.log('');
    return mergedMembers;
  }
  return pageLoaded([], await web.conversations.members(options));
}

const argv = require('yargs')
  .usage('Usage: node $0 <command> [options]')
  .command('get-userids', 'Reads a text file with e-mails and lookup their Slack userids')
  .command('create-channel', 'Creates a target channel in Slack')
  .command('invite-users','Invite a list of Slack userids to a target channel')
  .command('get-members','Reads members list from a source channel')
  .options({
    text_file : {
      demand : false,
      alias : 't',
      description : 'Text file with emails to be read (must exist in ./data)',
      type : 'string'
    },
    input_file : {
      demand : false,
      alias : 'i',
      description : 'JSON input file with Slack userids to be read (must exist in ./data)',
      type : 'string'
    },
    output_file : {
      demand : false,
      alias : 'o',
      description : 'JSON output file to be written (creates inside ./data)',
      type : 'string'
    },
    channel_name : {
        demand : false,
        alias : 'n',
        description : 'Slack channel name to create',
        type : 'string'
    },
    private_channel : {
        demand : false,
        alias : 'p',
        description : 'Wether the channel should be private or not',
        type : 'boolean'
    },
    slack_channel : {
        demand : false,
        alias : 'c',
        description : 'Target / Source Slack channel ID',
        type : 'string'
    },
    myself : {
        demand : false,
        alias : 'm',
        description : 'Your Slack userid',
        type : 'string'
    }
  })
  .demandCommand(1, 1, "You need to specify one command")
  .example('get-userids -t <text_file> -o <output_file>')
  .example('get-emails -i <input_file> -o <output_file>')
  .example('create-channel -n <channel_name> -p false -m <your_userid>')
  .example('invite-users -i <input_file> -c <slack_channel>')
  .example('get-members -o <output_file> -c <slack_channel>')
  .help('help').argv;

if (argv._ == 'get-userids') {
  if (argv.text_file && fs.existsSync(DataPath+argv.text_file)) {
    inviteesList = readTextFile(DataPath+argv.text_file);
    console.log(AppName+' - Total e-mails read from file: ',inviteesList.length);
    getSlackUserIds(inviteesList).then(function(data){
      if (argv.output_file) {
        fileName = DataPath+argv.output_file;
      } else {
        fileName = OutputFile;
      }
      usersList = data;
      console.log(AppName+' - Total userids consulted from Slack: ',usersList.length);
      console.log(AppName+' - Saving list of userids to file '+fileName);
      saveToFile(usersList, fileName);
      console.log(AppName+' - User IDs list has been saved to: '+fileName);
    });
  } else {
    console.error('Error: Please specify a valid text file under ./data folder as option!');
  }
} else if (argv._ == 'get-emails') {
  if (argv.input_file && fs.existsSync(DataPath+argv.input_file)) {
    membersList = readFromFile(DataPath+argv.input_file);
    //console.log(membersList);
    console.log(AppName+' - Total userids read from file: ',membersList.length);
    getSlackUserEmails(membersList).then(function(data){
      if (argv.output_file) {
        fileName = DataPath+argv.output_file;
      } else {
        fileName = OutputFile;
      }
      emailsList = data;
      console.log(AppName+' - Total e-mails consulted from Slack: ',emailsList.split(/\r\n|\r|\n/).length);
      console.log(AppName+' - Saving list of e-mails to file '+fileName);
      saveStringToFile(emailsList, fileName);
      console.log(AppName+' - E-mails list has been saved to: '+fileName);
    });

  } else {
    console.error('Error: Please provide an existing JSON file in the input_file option !');
  }
} else if (argv._ == 'create-channel') {
  if (argv.channel_name && argv.private_channel != null && argv.myself && argv.myself.length == 9) {
    createSlackChannel(argv.channel_name, argv.private_channel).then(function(channelId){
      console.log(AppName+' - Created Slack channel ID: ',channelId);
      inviteUsersToSlackChannel(channelId, argv.myself).then(function(ok){
        if (ok) {
          console.log(AppName+' - Added yourself to the created channel!');
        } else {
          console.log(AppName+' - I was not able to invite yourself to the channel!');
        }
      });
    });
  } else {
    console.error('Error: Please provide valid channel_name, private_channel and myself options!');
  }
} else if (argv._ == 'invite-users') {
  if (argv.slack_channel && argv.slack_channel.length >= 9) {
    if (argv.input_file) {
      fileName = DataPath+argv.input_file;
    } else {
      fileName = OutputFile;
    }
    if (fs.existsSync(fileName)) {
      usersList = readFromFile(fileName);
      //console.log(usersList);
      inviteManyToSlackChannel(argv.slack_channel, usersList).then(function(invited){
        console.log(AppName+' - Total userids invited to the Slack channel: '+invited);
      });
    } else {
      console.error('Error: Please provide an existing JSON file in the input_file option !');
    }
  } else {
    console.error('Error: Please provide valid channel ID in the slack_channel option !');
  }
} else if (argv._ == 'get-members') {
  usersList = [];
  if (argv.slack_channel && argv.slack_channel.length >= 9) {
    if (argv.output_file) {
      fileName = DataPath+argv.output_file;
    } else {
      fileName = OutputFile;
    }
    getAllChannelMembers({channel: argv.slack_channel}).then((members) => {
      console.log(AppName+' - Total members read from the Slack channel: '+members.length);
      for (let i = 0, length = members.length; i < length; i++) {
        usersList.push({
          userid: members[i],
          status: 'ok'
        });
      }
      saveToFile(usersList, fileName);
      console.log(AppName+' - Channel members list has been saved to: '+fileName);
    });
  }
} else {
  console.error('Invalid command, please run node app.js --help for more info');
}
