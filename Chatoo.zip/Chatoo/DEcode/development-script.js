(function executeRule(current, previous /*null when async*/ ) {

  var request;
  var updateParams = false;
  var existingTicket = false;
  var statusMapping = {
        "New": "NEW",
        "In Progress": "INPROGRESS",
        "On Hold": "HOLD",
        "Resolved": "RESOLVE",
        "Closed": "CLOSE",
        "Canceled": "CANCEL"
    };
  var previousAssignmentGroup = previous.getDisplayValue('assignment_group');
//  var assignmentGroups = ["C-DOW-IS-MAJORINCIDENT", "Kyndryl", "AT&T", "IBM groups", "C-DOW-IS-INCIDENTESCALATION", "I-Dow-IS-ISS-ZSCALER-L3", "I-DOW-IS-AVAYA-US-L2", "I-DOW-ME-INDSSO-INTEL"];
	var assignmentGroups = ['I-DOW-NASSO-AZURE-LINUX-L2', 'I-DOW-IS-NASSO-AZURE-WINDOWS-L2', 'I-DOW-IS-NWSME-GLOBAL-L2', 'I-DOW-IS-IBMNETWORK-OPS', 'V-DOW-US-ATTREMOTECLIENT', 'V-DOW-MSS-FW', 'I-DOW-IS-PRIVATECELL-OPS-L2', 'I-DOW-IS-VERSA-SDWAN-L2', 'V-DOW-CA-NSSIPS2', 'I-DOW-XXOPSGOC', 'I-DOW-INDSSO-AZURE', 'I-DOW-XXSSOBURSR-CORE-APPR', 'I-DOW-XXSSOBURSR', 'I-DOW-XXSSOBURIN', 'I-DOW-IS-CONNECTIVITY SERVICE-MGMT', 'I-DOW-WAAS-L3', 'I-DOW-BRSSO-INTEL', 'I-DOW-USSSOSERV-CORE-APPR', 'I-DOW-BRSSOPROJ', 'I-DOW-BRSSO-DECOM', 'I-DOW-ISMMISROUTE', 'I-DOW-USADMSEP', 'I-DOW-XXSSOSMNA', 'I-DOW-XXSSOSMNA-CORE-APPR', 'I-DOW-ME-INDSSO-INTEL', 'I-DOW-BRAGNNCR', 'V-DOW-US-UCAAS', 'V-DOW-XX-DNIVCNA', 'I-DOW-XXTIVDB2', 'V-DOW-IS-MSS-CUSTOM', 'I-DOW-IN-SCS', 'I-DOW-USSSOINFR', 'I-DOW-INDSSO-INTEL-CHANGE', 'I-DOW-INDSSO-INTEL', 'I-DOW-INDSSO-AZURE-UNIX', 'I-DOW-IN-SRM-MAL-POOL1', 'V-DOW-US-NSSQIP', 'I-DOW-XXEIMTIVC', 'I-DOW-CAAMSIPCC-CORE-APPR', 'I-DOW-CAAMSIPCC', 'I-DOW-IS-NS-SOLARWINDS-GLOBAL-L2', 'V-DOW-IS-LEGACY-IT-L2', 'V-DOW-IS-LEGACY-FR-L2', 'I-DOW-IS-LEGACYVOICE-EMEAI-UAE-L2', 'V-DOW-IS-MSS-IDS-IPS'];
  // add/remove any assignment group above. add assignmebt groups for which triggers are needed to chatops.
  // Could be handled via filter s as well.
  var assignmentGroupsVal = current.getDisplayValue("assignment_group");
  var assignmentGroupsAllowed = (assignmentGroups.indexOf(assignmentGroupsVal) > -1) || (assignmentGroups.indexOf(previousAssignmentGroup) > -1);
  if(!assignmentGroupsAllowed){
    return; // not do anything if incident assignment group not part of assignmentGroups list mentioned above.
  }
  if(!current.active){
    return; // not do anything if incident is not active..
  }
  var isChild = current.getDisplayValue('parent_incident').length > 0;	
  var incidentDesc = (current.short_description.toString() || current.description.toString());
  var commonData = {
    "accountCodeLocators": [{ "SearchKey": "accountCode", "SearchValue": "dow-test-1" }],
    "ticketId": current.number.toString(),
    "eventId": current.number.toString(),
    "ticketType": "incident",
    "ticketPriority": parseInt(current.getValue('priority')),
    "ticketImpact": current.getDisplayValue('impact').split("- ")[1].toString(),
    "ticketDesc": incidentDesc,
    "environment": "QA", // to be changes per env
    "ticketAssignmentGroups": current.getDisplayValue("assignment_group").split(",")		
  };
  var channelDetails = new sn_ws.RESTMessageV2("Chatops Channel Details", "post");
  var channelDetailsData = {
    "ticketId": current.number.toString(),
    "collabPlatform": "slack",
    "workspaceName": "",
    "channelId": "",
  };
  channelDetails.setRequestBody(JSON.stringify(channelDetailsData));
    var channelDetailsResponse = channelDetails.execute();
    var channelDetailsResponseBody = channelDetailsResponse.haveError() ? channelDetailsResponse.getErrorMessage() : channelDetailsResponse.getBody();
    var channelDetailsStatus = channelDetailsResponse.getStatusCode();
    parsedResponse = JSON.parse(channelDetailsResponseBody);
    if(typeof(parsedResponse) === "object" && parsedResponse && parsedResponse[0] && parsedResponse[0]["channelid"]){
      existingTicket = true;
      gs.log("Chatops BR" + " is a existing ticket");
      if(isChild){
        request = new sn_ws.RESTMessageV2("Chatops updateTicket", "post");
        commonData["resolver"] = current.getDisplayValue('resolved_by').toString();
        commonData["resolveTime"] = current.getValue('resolved_at');		
        commonData["status"] = 'downgraded';                  
        request.setRequestBody(JSON.stringify(commonData));
        response = request.execute();
        responseBody = response.haveError() ? response.getErrorMessage() : response.getBody();
        status = response.getStatusCode();	                 
        gs.log("Chatops BR : " + "is a child ticket going to delete");				
        return;
      }      				
    }

  if (current.operation() == "insert" && !isChild) {
    request = new sn_ws.RESTMessageV2("Chatops initiateTicket", "post");
  }
  if (current.operation() == "update" && !isChild) {
  gs.log("Chatops BR: " + "update operation detected");
  var priorityInt = parseInt(current.getValue('priority'));
  var isPriorityChanged = current.priority.changes();
  var updateFlag = current.state.changes() || current.resolved_by.changes() || current.resolved_at.changes() || current.assignment_group.changes() || current.resolved_by.changes() || current.ticketDesc.changes() || current.short_description.changes() || current.impact.changes();				
  var IncidentStatus = current.getDisplayValue('state').toString();        
  if(isPriorityChanged && priorityInt==1){ /*is priority changed to high/critical*/
    gs.log("Chatops BR: " + "priority change with P1 detected");       		
    if(typeof(parsedResponse) === "object" && parsedResponse && parsedResponse[0] && parsedResponse[0]["channelid"]){
      gs.log("Chatops BR" + " updating ticket for P1 change");
      updateParams = true;				
    }else{
      gs.log("Chatops BR" + " creating ticket for P1 change");				
      request = new sn_ws.RESTMessageV2("Chatops initiateTicket", "post");
    }    
  }
  else if(updateFlag || isPriorityChanged){
    /*For existing ticket, Priority changes to HIGH/Critical ***/
    /*only if the specific fields change the update should work. Also when High/Critical  to other prioirty*/				
      gs.log("Chatops BR: " + "priority change with update in ticket status etc detected");
    if(typeof(parsedResponse) === "object" && parsedResponse && parsedResponse[0] && parsedResponse[0]["channelid"]){
      gs.log("Chatops BR" + " updating ticket for P1 change");
      updateParams = true;				
    }else{
      gs.log("Chatops BR" + " creating ticket for P1 change");				
      request = new sn_ws.RESTMessageV2("Chatops initiateTicket", "post");
    }	
  }else if(current.major_incident_state.changes()){
    if(existingTicket){
        gs.log("Chatops BR: " + "major incident changes detected");
        updateParams = true; 
      }else{
        request = new sn_ws.RESTMessageV2("Chatops initiateTicket", "post");
        updateParams = false;
    }
          
  }else{
    gs.log("Chatops BR: " + "Nothing matched returning");
    return;
  }			
  }	
  if(updateParams && !isChild){
    request = new sn_ws.RESTMessageV2("Chatops updateTicket", "post");
    commonData["resolver"] = current.getDisplayValue('resolved_by').toString();
    commonData["resolveTime"] = current.getValue('resolved_at');		
    if(parseInt(previous.getValue('priority')) === 1){
      commonData["status"] = 'DOWNGRADED';
    }else{
      commonData["status"] = statusMapping[IncidentStatus];
    }
  }
  if(!isChild){
    request.setRequestBody(JSON.stringify(commonData));
    response = request.execute();
    responseBody = response.haveError() ? response.getErrorMessage() : response.getBody();
    status = response.getStatusCode();	
    gs.info("Chatops BR Status: " + status);
    gs.info("Chatops BR Payload: " + JSON.stringify(commonData));
    gs.info("Chatops BR Response: " + responseBody);
  }
})(current, previous);

