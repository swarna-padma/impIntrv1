var axios = require('axios');
var https = require('https');
const axiosConfig = {
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'X-Chatops-Source-Api-Token': 'COAK-09be0fb8-5180-4efb-9ab7-f140b07039a9', //change this to required toekn
    'X-Chatops-Source-Id': 'snow-dev95365', // change this to required value
    'X-Transaction-Id': '12345'
  },
  httpsAgent: new https.Agent({
    rejectUnauthorized: false,
  }),
}
let postData = {
  "collabPlatform": "slack",
  "workspaceName": "TEST - GLOBAL", // change it to required value
  "channelId": ""  
}
// change below to required value
const channelDetailsUrl = 'https://chatops-dev-int.extnet.ibm.com/api/v1/getChatPlatformInfo/sync';
const archiveChannelUrl = 'https://chatops-dev-int.extnet.ibm.com/api/v1/archiveChannel/sync';
// change below to required value
const ticketNumbers = ["INC3096630", "INC3106405", "INC3107850", "INC3108029", "INC3108638", "INC3108972", "INC3109852", "INC3110029", "INC3110688", "INC3111637", "INC3112335", "INC3112342", "INC3112706", "INC3112707", "INC3112791", "INC3112877", "INC3113031", "INC3113045", "INC3113264", "INC3113300", "INC3113377", "INC3113463", "INC3113464", "INC3113691", "INC3113700", "INC3113701", "INC3113724", "INC3113789", "INC3113793", "INC3113820", "INC3113829", "INC3113901"] ;
let successList = [];
let errorList = [];
async function getChannelDetails(channelDetailsData) {  
  let apiResponse, apiError;
  await axios
  .post(channelDetailsUrl, channelDetailsData, axiosConfig)
  .then((response) => {
    // console.log('response recieved get', response);
    apiResponse = response.data;
  })
  .catch((error) => {    
    console.log(`Error at post ${error}`);
    apiError = error;
  });
  return [apiResponse, apiError];
}

async function archiveChannel(archiveChannelData) {  
  let apiResponse, apiError;
  await axios
  .post(archiveChannelUrl, archiveChannelData, axiosConfig)
  .then((response) => {
    apiResponse = response.data;
  })
  .catch((error) => {    
    apiError = error;
  });
  return [apiResponse, apiError];
}

async function acrhiveChannelDow(params) {

for(let i=0; i < ticketNumbers.length; i++){
  try{
    postData["ticketId"] = ticketNumbers[i]
    const channelDetails = await getChannelDetails(postData);
    const channelId = channelDetails[0][0]['channelid'];
    console.log("channelDetails");
    console.log(channelDetails[0][0]['channelid']);
    console.log(channelDetails[1]);
    if(channelId){  
      delete postData["ticketId"];
      postData["channelId"] = channelId;
      const archivalResponse = await archiveChannel(postData);
      isArchived = archivalResponse[0][0]["ok"];
      console.log("archivalDetails");
      console.log(archivalResponse[0][0]["ok"]);
      console.log(archivalResponse[1]);
      if(isArchived){
        successList.push(ticketNumbers[i]);
      }else{
        errorList.push(ticketNumbers[i]);
      }
    }
  }catch(err){
    console.log(err);
    errorList.push(ticketNumbers[i]);
  }
}
  console.log("++++++++BEGIN++++++++++");
  console.log("successList Below");  
  console.log(successList);
  console.log("+++++++++END+++++++++");
  
  console.log("++++++++BEGIN++++++++++"); 
  console.log("errorList Below"); 
  console.log(errorList);
  console.log("+++++++++END+++++++++");
}

acrhiveChannelDow();
